# tele_bom_bang_new (or) ENERGY | v11 (or) edit 11
ستاره یادت نره حمایت کن دمت گرم
****************************************************
sudo apt-get install libreadline-dev libconfig-dev libssl-dev lua5.2 liblua5.2-dev lua-socket lua-sec lua-expat libevent-dev make unzip git redis-server autoconf g++ libjansson-dev libpython-dev expat libexpat1-dev ppa-purge python3-pip python3-dev

************************************************************************
cd $HOME && git clone https://github.com/telebombang2018/energy.git && cd energy && chmod +x energy.sh && ./energy.sh install && ./energy.sh
________
*****************
نصب اتولانچ
--------------
cd energy 

chmod +x autoenergy.sh 

screen ./autoenergy.sh
*****************
لانچ دوباره
--------------
killall screen

cd energy && chmod +x autoenergy.sh && screen ./autoenergy.sh

*****************
--------------
کانال ما برای دریافت اپدیت ها و دریافت هلپر

@mohammadbots

@mohammadbots
